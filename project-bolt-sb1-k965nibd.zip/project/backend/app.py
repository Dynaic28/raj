from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import httpx
import asyncio
from fastapi.responses import StreamingResponse, JSONResponse

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # Vite dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

OLLAMA_BASE_URL = "http://localhost:11434"

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    model: str
    messages: List[Message]
    stream: bool = True
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None

async def check_ollama_connection():
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{OLLAMA_BASE_URL}/api/tags")
            return response.status_code == 200
        except Exception:
            return False

@app.get("/api/models")
async def get_models():
    if not await check_ollama_connection():
        return JSONResponse(
            status_code=503,
            content={"error": "Ollama server is not running or not accessible"}
        )

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{OLLAMA_BASE_URL}/api/tags")
            if response.status_code != 200:
                return JSONResponse(
                    status_code=response.status_code,
                    content={"error": "Failed to fetch models from Ollama"}
                )
            data = response.json()
            models = data.get("models", [])
            if not models:
                return JSONResponse(
                    status_code=404,
                    content={"error": "No models found"}
                )
            return models
        except Exception as e:
            return JSONResponse(
                status_code=500,
                content={"error": f"Failed to connect to Ollama: {str(e)}"}
            )

@app.post("/api/chat")
async def chat(request: ChatRequest):
    if not await check_ollama_connection():
        return JSONResponse(
            status_code=503,
            content={"error": "Ollama server is not running or not accessible"}
        )

    async def stream_response():
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{OLLAMA_BASE_URL}/api/chat",
                    json=request.dict(),
                    timeout=None
                )
                if response.status_code != 200:
                    yield f"Error: {response.text}\n"
                    return
                async for line in response.aiter_lines():
                    yield line + "\n"
            except Exception as e:
                yield f"Error: {str(e)}\n"

    return StreamingResponse(
        stream_response(),
        media_type="text/event-stream"
    )

@app.get("/api/health")
async def health_check():
    is_connected = await check_ollama_connection()
    return {
        "status": "healthy" if is_connected else "degraded",
        "ollama": "connected" if is_connected else "not connected"
    }