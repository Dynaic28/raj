export interface OllamaModel {
  name: string;
  size: number;
  modified_at: string;
  digest: string;
}

export interface ModelDetails {
  name: string;
  modelfile: string;
  template: string;
  parameters: string;
  license: string;
  system: string;
}