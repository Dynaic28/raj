import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Message, Conversation, ModelConfig } from './types/chat';
import { streamCompletion } from './lib/api';
import { loadConversations, saveConversation } from './lib/storage';
import { MessageList } from './components/Chat/MessageList';
import { MessageInput } from './components/Chat/MessageInput';
import { ModelSelector } from './components/Chat/ModelSelector';
import { ConversationList } from './components/Chat/ConversationList';

function App() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loaded = loadConversations();
    setConversations(loaded);
    if (loaded.length > 0) {
      setCurrentConversation(loaded[0]);
    } else {
      createNewConversation();
    }
  }, []);

  const createNewConversation = () => {
    const newConversation: Conversation = {
      id: uuidv4(),
      title: 'New Chat',
      messages: [],
      model: 'llama2',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations((prev) => [...prev, newConversation]);
    setCurrentConversation(newConversation);
    saveConversation(newConversation);
  };

  const handleSend = async (content: string) => {
    if (!currentConversation) return;

    const userMessage: Message = {
      role: 'user',
      content,
      timestamp: Date.now(),
    };

    const updatedConversation = {
      ...currentConversation,
      messages: [...currentConversation.messages, userMessage],
      updatedAt: Date.now(),
    };

    if (updatedConversation.messages.length === 1) {
      updatedConversation.title = content.slice(0, 30) + '...';
    }

    setCurrentConversation(updatedConversation);
    saveConversation(updatedConversation);

    setIsLoading(true);
    let assistantMessage = '';

    try {
      const modelConfig: ModelConfig = {
        name: currentConversation.model,
        temperature: 0.7,
      };

      await streamCompletion(
        updatedConversation.messages,
        currentConversation.model,
        modelConfig,
        (chunk) => {
          assistantMessage += chunk;
          setCurrentConversation((prev) => {
            if (!prev) return null;
            const messages = [...prev.messages];
            if (messages[messages.length - 1]?.role === 'assistant') {
              messages[messages.length - 1].content = assistantMessage;
            } else {
              messages.push({
                role: 'assistant',
                content: assistantMessage,
                timestamp: Date.now(),
              });
            }
            return { ...prev, messages };
          });
        }
      );
    } catch (error) {
      console.error('Error in chat completion:', error);
    } finally {
      setIsLoading(false);
      if (currentConversation) {
        saveConversation(currentConversation);
      }
    }
  };

  const handleModelChange = (model: string) => {
    if (currentConversation) {
      const updated = { ...currentConversation, model };
      setCurrentConversation(updated);
      saveConversation(updated);
    }
  };

  const handleDeleteConversation = (id: string) => {
    setConversations((prev) => {
      const filtered = prev.filter((c) => c.id !== id);
      if (currentConversation?.id === id) {
        setCurrentConversation(filtered[0] || null);
      }
      return filtered;
    });
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <ConversationList
        conversations={conversations}
        selectedId={currentConversation?.id || null}
        onSelect={(id) => {
          const selected = conversations.find((c) => c.id === id);
          if (selected) setCurrentConversation(selected);
        }}
        onDelete={handleDeleteConversation}
        onNew={createNewConversation}
      />
      <div className="flex-1 flex flex-col">
        {currentConversation && (
          <>
            <ModelSelector
              selectedModel={currentConversation.model}
              onModelChange={handleModelChange}
            />
            <div className="flex-1 overflow-y-auto">
              <MessageList messages={currentConversation.messages} />
            </div>
            <MessageInput onSend={handleSend} disabled={isLoading} />
          </>
        )}
      </div>
    </div>
  );
}

export default App;