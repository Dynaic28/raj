import { API_BASE_URL } from '../config';
import { OllamaModel } from '../../types/models';
import { ApiError } from '../errors';

export async function fetchAvailableModels(): Promise<OllamaModel[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/api/models`);
    
    if (!response.ok) {
      const errorData = await response.text();
      throw new ApiError('Failed to fetch models', response.status, errorData);
    }

    const data = await response.json();
    if (!Array.isArray(data)) {
      throw new ApiError('Invalid models response', 500);
    }

    return data;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    throw new ApiError(
      'Failed to fetch models',
      500,
      error instanceof Error ? error.message : String(error)
    );
  }
}