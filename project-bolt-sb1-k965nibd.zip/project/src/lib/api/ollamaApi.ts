import { Message, ModelConfig } from '../../types/chat';
import { API_BASE_URL } from '../config';
import { ApiError } from '../errors';

export async function streamCompletion(
  messages: Message[],
  model: string,
  config: ModelConfig,
  onChunk: (chunk: string) => void
): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        messages: messages.map(({ role, content }) => ({ role, content })),
        stream: true,
        ...config,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new ApiError('Chat API Error', response.status, errorData);
    }

    if (!response.body) {
      throw new ApiError('Stream not available', 500);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter(Boolean);
      
      for (const line of lines) {
        try {
          const parsed = JSON.parse(line);
          if (parsed.message?.content) {
            onChunk(parsed.message.content);
          }
        } catch (e) {
          console.error('Error parsing chunk:', e);
          throw new ApiError('Failed to parse stream chunk', 500);
        }
      }
    }
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    throw new ApiError('Stream error', 500, error instanceof Error ? error.message : String(error));
  }
}