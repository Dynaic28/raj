import { Message, ModelConfig } from '../types/chat';

const OLLAMA_HOST = 'http://localhost:11434'; // Change this for production

export async function streamCompletion(
  messages: Message[],
  model: string,
  config: ModelConfig,
  onChunk: (chunk: string) => void
): Promise<void> {
  try {
    const response = await fetch(`${OLLAMA_HOST}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        messages: messages.map(({ role, content }) => ({ role, content })),
        stream: true,
        ...config,
      }),
    });

    if (!response.ok || !response.body) {
      throw new Error('Stream response not available');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter(Boolean);
      
      for (const line of lines) {
        try {
          const parsed = JSON.parse(line);
          if (parsed.message?.content) {
            onChunk(parsed.message.content);
          }
        } catch (e) {
          console.error('Error parsing chunk:', e);
        }
      }
    }
  } catch (error) {
    console.error('Stream error:', error);
    throw error;
  }
}