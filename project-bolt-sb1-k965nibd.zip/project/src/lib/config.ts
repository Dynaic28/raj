// API configuration
export const API_BASE_URL = import.meta.env.PROD 
  ? '/api' 
  : 'http://localhost:8000';  // Remove /api since it's included in the endpoints

// Chat configuration
export const DEFAULT_MODEL = 'llama2';
export const DEFAULT_TEMPERATURE = 0.7;

// Storage configuration
export const STORAGE_KEY = 'ollama-conversations';