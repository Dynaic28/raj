import { useState, useEffect } from 'react';
import { OllamaModel } from '../types/models';
import { fetchAvailableModels } from '../lib/api/modelApi';
import { ApiError } from '../lib/errors';

export function useModels() {
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function loadModels() {
      try {
        const availableModels = await fetchAvailableModels();
        if (mounted) {
          setModels(availableModels);
          setError(null);
        }
      } catch (err) {
        if (mounted) {
          const message = err instanceof ApiError
            ? `${err.message}${err.details ? `: ${err.details}` : ''}`
            : 'Failed to load models';
          setError(message);
          setModels([]);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    }

    loadModels();
    return () => { mounted = false; };
  }, []);

  return { models, isLoading, error };
}