import React from 'react';
import { useModels } from '../../hooks/useModels';
import { Loader } from 'lucide-react';

interface ModelSelectorProps {
  selectedModel: string;
  onModelChange: (model: string) => void;
}

export function ModelSelector({ selectedModel, onModelChange }: ModelSelectorProps) {
  const { models, isLoading, error } = useModels();

  if (isLoading) {
    return (
      <div className="p-4 border-b flex items-center justify-center">
        <Loader className="w-5 h-5 animate-spin text-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 border-b text-red-500 text-sm">
        Failed to load models
      </div>
    );
  }

  return (
    <div className="p-4 border-b">
      <select
        value={selectedModel}
        onChange={(e) => onModelChange(e.target.value)}
        className="w-full p-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        {models.map((model) => (
          <option key={model.name} value={model.name}>
            {model.name}
          </option>
        ))}
      </select>
    </div>
  );
}