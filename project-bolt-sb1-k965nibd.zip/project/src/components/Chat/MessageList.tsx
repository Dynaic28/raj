import React from 'react';
import { Message } from '../../types/chat';
import { UserCircle, Bot } from 'lucide-react';

interface MessageListProps {
  messages: Message[];
}

export function MessageList({ messages }: MessageListProps) {
  return (
    <div className="flex flex-col space-y-4 p-4">
      {messages.map((message, index) => (
        <div
          key={index}
          className={`flex items-start space-x-3 ${
            message.role === 'assistant' ? 'bg-gray-50' : ''
          } p-4 rounded-lg`}
        >
          <div className="flex-shrink-0">
            {message.role === 'user' ? (
              <UserCircle className="w-6 h-6 text-blue-500" />
            ) : (
              <Bot className="w-6 h-6 text-green-500" />
            )}
          </div>
          <div className="flex-1">
            <p className="text-sm text-gray-800 whitespace-pre-wrap">
              {message.content}
            </p>
            <span className="text-xs text-gray-400 mt-1">
              {new Date(message.timestamp).toLocaleTimeString()}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}