import React from 'react';
import { MessageSquare, Trash2 } from 'lucide-react';
import { Conversation } from '../../types/chat';

interface ConversationListProps {
  conversations: Conversation[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onNew: () => void;
}

export function ConversationList({
  conversations,
  selectedId,
  onSelect,
  onDelete,
  onNew,
}: ConversationListProps) {
  return (
    <div className="w-64 border-r bg-gray-50 p-4">
      <button
        onClick={onNew}
        className="w-full p-2 mb-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
      >
        New Chat
      </button>
      <div className="space-y-2">
        {conversations.map((conv) => (
          <div
            key={conv.id}
            className={`flex items-center justify-between p-2 rounded-lg cursor-pointer ${
              selectedId === conv.id ? 'bg-blue-100' : 'hover:bg-gray-100'
            }`}
            onClick={() => onSelect(conv.id)}
          >
            <div className="flex items-center space-x-2 truncate">
              <MessageSquare className="w-4 h-4" />
              <span className="truncate text-sm">{conv.title}</span>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(conv.id);
              }}
              className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 rounded"
            >
              <Trash2 className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}